<?php
    echo "<a href='#' onclick=\"document.getElementById('divFlutuante').style.display='none';\">[Fechar]</a>";
    echo "<br />Agora coloque o estilo dessa div.";
?>

timezone