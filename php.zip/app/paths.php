	<?php
    $DivcolPath = './tabelas/'; // \COLICON\DIVCOL\Fracao\COMPRAS\PLANILHA...
    $DivconPath = './tabelas/';
    $UploadPath = '../tabelas/';
  ?>
