<?php 
    require('app/divcol.php');
    require('app/divcon.php');
?>