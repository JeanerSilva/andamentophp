# andamentophp

php-excel-reader\paths.php - local de configuração do caminho para as pastas da rede


intranet.html - link para constar na intranet



indexphp.php - arquivo php principal

